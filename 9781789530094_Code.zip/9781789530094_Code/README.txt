Mastering Visual Studio 2019

Chapters 1, 6, 7, and 9 don't have code files