const author = "Kunal Chowdhury";
author = "some other author"; // error: can't assign to 'author' because it is a constant