function GetBook(title: string, year: number) {
    var title = "Mastering Visual Studio 2017";
    
    var title = "Windows Presentation Foundation " + 
                "Development Cookbook"; // no error
    
    if (year == 2019) {
        var title = "Mastering Visual Studio 2019"; // no error
        
    }
}