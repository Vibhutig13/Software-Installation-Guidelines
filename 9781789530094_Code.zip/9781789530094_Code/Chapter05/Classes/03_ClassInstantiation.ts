let person: Person = new Person("Kunal", "Chowdhury", 30);
console.log("Person name: " + person.getFullName());

// alternate way
let person = new Person("Kunal", "Chowdhury", 30);
console.log("Person name: " + person.getFullName());