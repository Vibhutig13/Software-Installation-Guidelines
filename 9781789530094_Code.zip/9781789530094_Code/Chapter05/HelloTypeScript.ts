// create a function that accepts a person name of type string
function greet(person : string) {
    // greet the user with customized message
    console.log(`Hello ${person}, Welcome to TypeScript`);
}

// call the function passing the name of the person
greet("reader");