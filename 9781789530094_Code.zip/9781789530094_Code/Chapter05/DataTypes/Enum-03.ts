enum MessageType { 
    None = 1,           // value is '1'
    Information = 3,    // value is '3'
    Warning = 5,        // value is '5'
    Error = 7           // value is '7'
}