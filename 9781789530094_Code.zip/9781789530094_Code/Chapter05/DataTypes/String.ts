//#region string types
let firstName: string = "Kunal";		// using double quotes
let lastName: string = 'Chowdhury';	// using single quotes

let authorName: string = "Kunal Chowdhury";
let blogURL: string = "https://www.kunal-chowdhury.com"; 
let message: string = `Hi, my name is ${authorName}.
 
I do blog at ${blogURL}. Don't forget to visit it.`; 
//#endregion string types