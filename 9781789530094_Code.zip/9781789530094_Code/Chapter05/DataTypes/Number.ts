//#region number types
let decimalValue: number = 100.25;
let binaryValue: number = 0b10110010;
let hexaDecimalValue: number = 0xf210b;
let octalValue: number = 0o41530;
//#endregion number types