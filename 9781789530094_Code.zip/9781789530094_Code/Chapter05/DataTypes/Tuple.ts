//#region tuple types
let author: [string, number] = ["Kunal Chowdhury", 2019];
let values: [string, number] = ["One", 1, "Two", 2];

// let values: [string, number] = ["One", 1];		// correct
// let values: [string, number] = ["One", 1, "Two"];	// correct
// let values: [string, number] = [1, "One"];		// error
// let values: [string, number] = ["One", 1, 2];		// error
// let values: [string, number] = ["One", 1, true];	// error
//#endregion tuple types