//#region undefined types
let undefinedValue: undefined = undefined;
let undefinedNumber: number = undefined;
let undefinedBoolean: boolean = undefined;
//#endregion undefined types