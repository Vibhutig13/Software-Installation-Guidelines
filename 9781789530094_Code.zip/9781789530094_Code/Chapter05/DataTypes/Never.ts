//#region never types
function throwError(message: string): never {
	throw new Error(message);
}
//#endregion never types