    // approach two (generic way):
    let books: Array<string> = [
        "Mastering Visual Studio 2017",
        "Mastering Visual Studio 2019",
        "Windows Presentation Foundation Development Cookbook"
        ];   