//#region null types
let nullValue: null = null;
let nullableNumeric: number = null;
let nullableBoolean: boolean = null;
//#endregion null types