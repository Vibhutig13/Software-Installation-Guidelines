//#region any types
let dynamicValue: any = "Kunal Chowdhury";
dynamicValue = 2019;
dynamicValue = 0b100110111001;
dynamicValue = 0o411021;
dynamicValue = true;

let dynamicList: any[] = [ "Mastering Visual Studio 2019",
    "Kunal Chowdhury",
    2019,
    True
  ];  
//#endregion any types