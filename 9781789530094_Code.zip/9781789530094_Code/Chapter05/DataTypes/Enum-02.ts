enum MessageType { 
    None = 1,       // value is '1'
    Information,    // value is '2'
    Warning,        // value is '3'
    Error           // value is '4'
}