﻿using System.Linq;
using System.Windows;

namespace Demo.WPF.FirstApp
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            //// Command line arguments
            //var args = e.Args;
            //if (args != null && args.Count() > 0)
            //{
            //    foreach (var arg in args)
            //    {
            //        MessageBox.Show("Parameter Passed: " + arg);
            //    }
            //}
        }
    }
}
